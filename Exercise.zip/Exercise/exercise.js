const http = require('http');
const fs = require('fs');
const { Http2ServerResponse } = require('http2');
const hostname = "127.0.0.1";
const port = 8081;

var server = http.createServer((request, response) => {
    response.writeHead(200, {'Content-Type': 'text/html'});
    const data = fs.readFileSync("exercise.html");
    response.end(data);
    // response.write('<p>Simple Text</p>');
    response.end()
})
server.listen(port, hostname, function(){
    console.log(`Server running at ${hostname}:${port}`);
});
